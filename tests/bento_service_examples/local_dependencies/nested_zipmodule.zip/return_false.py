def return_false():
    return False
