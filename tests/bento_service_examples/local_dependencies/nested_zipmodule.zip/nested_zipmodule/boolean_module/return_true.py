import logging

logger = logging.getLogger(__name__)


def return_true():
    return True
